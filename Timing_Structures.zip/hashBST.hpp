#ifndef HASHBST_HPP
#define HASHBST_HPP

#include <string>
#include "BST.hpp"


using namespace std;


class HashTable
{
    int tableSize;  // No. of buckets (linked lists)

    // Pointer to an array containing buckets
    BST *table;
    int numOfcolision =0;

public:
    HashTable(int bsize);  // Constructor
    ~HashTable();

    // inserts a key into hash table
    bool insertItem(int key);

    void resetCollisons();

    // hash function to map values to key
    unsigned int hashFunction(int key);

    //printing the tbake 
    void printTable();

    //geting the number of collisions
    int getNumOfCollision();

    // searching for the key 
    bool searchItem(int key);
};

#endif
