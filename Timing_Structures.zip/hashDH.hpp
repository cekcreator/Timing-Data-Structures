#ifndef HASH_HPP
#define HASH_HPP

#include <string>

using namespace std;


class HashTable
{
    int tableSize;  // No. of buckets (linked lists)

    // Pointer to an array containing buckets
    int *table;
    int numOfcolision =0;

public:
    HashTable(int bsize);  // Constructor
    ~HashTable();

    void resetCollisons();
    // inserts a key into hash table
    bool insertItem(int key);

    // hash function to map values to key
    unsigned int hashFunction(int key);

    // hash function for double hashing
    unsigned int hashFunctionDH(int key);
    // printing the able 
    void printTable();
    //returnignthe number of collisions
    int getNumOfCollision();
    // searching the data 
    int searchItem(int key);
};

#endif
