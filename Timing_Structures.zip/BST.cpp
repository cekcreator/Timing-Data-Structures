#include "BST.hpp"
#include "hashBST.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

//constructor 
BST::BST()
{
    root = NULL;
}

//heloer function for the deconstructor
void destroyNode(Node* curr)
{ 
  if (curr != NULL)     // going through the tree recursively and deleting the left node first 
  {
    destroyNode(curr->left);            // left child first then right 
    destroyNode(curr->right);
    delete curr;                    // deleting and freeing the node 
    curr = NULL;
  }
  return;
}

//deconstrctor 
BST::~BST()
{
    destroyNode(root);
    root = NULL;
}

// creating a new node for the tree
Node* BST::createNode(int data)
{
    Node* nn = new Node;
    nn->key = data;
    nn->right = NULL;
    nn->left = NULL;
    return nn;
}

// search function helper to find the key recersively
Node* BST::searchKeyHelper(Node* curr, int key)
{
    if (curr == NULL)   // base case
        return curr;

    if (curr->key == key)   // if key is found
        return curr;
    
    if (curr->key < key)        // recursove call 
        return searchKeyHelper(curr->right, key);
    
    return searchKeyHelper(curr->left, key);    // recursive call 
}

// helper ffuntion for creating the node 
Node* BST::addNodeHelper(Node* curr, int key)
{
    if (curr == NULL)           // base case, found the leaf node 
    {
        return createNode(key);
    }
    else if (curr->key == key)      // adding the key to the parents right child place if they are equal did add here 
    {
        curr->right = addNodeHelper(curr->right, key);
        //numOfcollison++;
    }
    else if (curr->key < key)       // adding to the right child area
    {
        curr->right = addNodeHelper(curr->right, key);
    }   
    else if (curr->key > key)           // adding to the left child area 
    {
        curr->left = addNodeHelper(curr->left, key);
    }
    return curr; 
}

// print function helper prints out in pre order way
void BST::printTreeHelper(Node* curr)
{
    if (curr)
    {
        printTreeHelper(curr->left);            // left then 
        cout << "Key: " << curr->key << endl; 
        printTreeHelper(curr->right);
    }
    return; 
}

void BST::addNode(int key)             // function to insert a node in the tree.
{
    root = addNodeHelper(root, key);
}


bool BST::searchKey(int key)   // function to search a data in the tree
{
    Node* temp = searchKeyHelper(root, key);
    if (temp == NULL)                               // if the key was not found
    {
        return false;
    }
    else                                // if the key was found
    {
        return true;
    }
}

void BST::printTree()              //function to print the tree
{
    if (root == NULL)
    {
        cout << "Tree is empty. Cannot print" << endl;
        return;
    }
    else 
    {
        printTreeHelper(root); // printing the tree 
    }
}

bool BST::isEmpty() //checking to see if the tree is empty 
{
    if (root == NULL)
        return true;
    return false;
}

int BST::getRoot()      // return the root/index of the bst 
{
    if (root == NULL)
        return -1;
    return root->key;
}