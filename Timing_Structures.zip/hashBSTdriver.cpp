#include "hashBST.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include <random>
#include <unistd.h>
#include <thread>
#include "time.h"

using namespace std;

int main()
{
    // variables for use , hard coded input and out put files
    int bsize = 10009;
    HashTable insert(bsize);
    ifstream read("dataSetA-updated.csv"); 
    ofstream write("insert_search_performance_hashBST.csv");
    string line;
    int avgInsert = 0;
    int avgSearch = 0;
    int totalArr[10000];
    float insertTime[50];
    float searchTime[50];
    srand(time(0));             //seeding the time 
    int randNum = -1;
    int arrNum = -1;
    int q = 0;
    bool found;
    double time = 0;
    int randArr[200];
    int insertcollArr[50];
    int searchcollArr[50];

    int n = 0;
    while (getline(read, line, ','))        // inserting the data from the fle into the array 
    {
        int num = stoi(line);
        totalArr[n] = num;
        n++;
    }

    for (unsigned int i = 0; i < 50; i++)       // loop for the total interations
    {   
        // starting and doing the insertion of data into the dll
        auto start = chrono::steady_clock::now();
        for (unsigned int k = q; k < q + 200; k++)
        {
            insert.insertItem(totalArr[k]);
        }
        auto end = chrono::steady_clock::now();  // end time of the insertion 

        insertcollArr[i] = insert.getNumOfCollision();      // inserting the number of insert collisions

        insertTime[i] = chrono::duration_cast<chrono::nanoseconds>(end - start).count();  // getting the time it took for insertion
        avgInsert += chrono::duration_cast<chrono::nanoseconds>(end - start).count();

        insert.resetCollisons();        // resetting the number of collisons for the insert count to count for the search 

        for (unsigned int d = 0; d < 200; d++)  // generates the random numbers and inserts them into an array for use
        {
            randArr[d] = rand() % (200 + q);
        }

        auto start2 = chrono::steady_clock::now();       // starting timer for searching
        for (unsigned int a = 0; a < 200; a++)
        {
            randNum = randArr[a]; 
            arrNum = totalArr[randNum];         // checks random index 
            insert.searchItem(arrNum);     //returns bool just incase need to confirm 
        }
        auto end2 = chrono::steady_clock::now();         // end time 

        searchcollArr[i] = insert.getNumOfCollision();      //inserting the number of search collisions 

        searchTime[i] = chrono::duration_cast<chrono::nanoseconds>(end2 - start2).count(); // calculates time
        avgSearch += chrono::duration_cast<chrono::nanoseconds>(end2 - start2).count();
        q += 200; // keeping track of index in the totalArr
    } 

    for (int b = 0; b < 50; b++) // writing the insert times to the file 
    {
        write  << insertTime[b] / 200  << endl;
    }
    write << "Search time below, insert time above" << endl;        // writing the search times to the file 
    for (int g = 0; g < 50; g++)
    {
        write << searchTime[g] / 200  << endl;
    }

    // these are unneeded, they were for my refernce 
    write << "Average insert time: " << (avgInsert / 200) << " , Average search time: " << (avgSearch / 200) << endl; 
    int collison = insert.getNumOfCollision();

    // wiritng the number of collisions
    write << "Number of total collisions: " << collison << endl; 
    write << "Number of collisions for insertion: " << endl;
    for (int a = 0; a < 50; a++)// writing the number of insert collisions
    {
        write << insertcollArr[a] << endl;
    }
    write << "Number of collisions for searching: " << endl;        // wiritng the number of search collisions 
    for (int c = 0; c < 50; c++)
    {
        write << searchcollArr[c] << endl;
    }

    // closing and destroying the table 
    write.close();

    insert.~HashTable();
    return 0;
}