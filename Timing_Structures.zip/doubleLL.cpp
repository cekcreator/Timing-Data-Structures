#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "doubleLL.hpp"

using namespace std;

//constructor 
doubleLL::doubleLL()
{
    head = NULL;
    tail = NULL;
}
//deconstructor
doubleLL::~doubleLL() // desctructor 
{
    Node* temp = head;
    while (head)        // deleting the node and freeing the space
    {   
        temp = head;
        head = head->next;  // setting head to the next node and freeing that node 
        delete temp;
    }
    head = NULL;
}


void doubleLL::deleteNode(int key) // deletes a node
{
    if (head == NULL)
    {
        return;
    }

    Node* current = head;   // using to find the node
    Node* prev = NULL;

    if (head->key == key)
    {
        head = head->next;      // deleting if the head node is the key to delete
        delete current;
    }

    while (current != NULL &&  current->key != key)     // finding the ky
    {
        prev = current;
        current = current->next;
    }
    if (current == NULL)
    {
        return;
    }
    else
    {
        prev->next = current->next;     // deleting the found key
        delete current;
    }
}

void doubleLL::search(int key)      // searching for the key
{
    Node* temp = head;
    if (temp == NULL)       // if the list is empty 
    {
        return; 
    }   
    if (head->key == key)       // if the head is the key
    {   
        return;
    }
    while (temp)        // traverses the list 
    {
        if (temp->key == key)
        {
            return;         // retruning the key 
        }
        temp = temp->next; 
    }
    if (temp == NULL)
    return;
}

void doubleLL::addNode(int key) // adds a node to the list
{
    Node* nn = new Node;
    nn->key = key;
    nn->next = NULL;
    nn->prev = NULL;        // creating the new node 

    if (head == NULL)       // adsding to the head of an empty list 
    {
        head = nn; 
        tail = nn;
    }
    else                    // adding to the end of the list 
    {
        //Node* temp = head;
        tail->next = nn;
        nn->prev = tail;
        tail = nn; 
    }
}

void doubleLL::print()      // prints out the tree from head to tail 
{  
    if (head == NULL)       // if list is empty 
    {   
        cout << "Empty list, add items before printing again." << endl; 
        return; 
    }
    Node* temp = head;
    cout << "Items in the doubly linked list.";
    while(temp)                                     // traverses the list and prints out keys
    {
        cout << temp->key;
        if (temp-> next == NULL)            // end of the list 
            break;
        cout << " -> ";
        temp = temp->next;
    }
    cout << endl; 
    return; 
}
