#ifndef doubleLL_HPP
#define doubleLL_HPP

using namespace std;

// node structrue 
struct Node
{
    int key;
    Node* next;
    Node* prev;
};

class doubleLL
{
    private: 
        Node* head; // ptr to the head of the dLL
        Node* tail; //ptr to the end of the list 
    
    public:
        doubleLL(); // constructor
        ~doubleLL(); // desctructor 
        void deleteNode(int key); // deletes a node
        void addNode(int key); // adds a node to the list
        void print();
        void search(int key); // returns the node of a given key
};

#endif