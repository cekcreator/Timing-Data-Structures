#include "hashDH.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include<cmath>

using namespace std;

// construcotr 
HashTable::HashTable(int bsize)
{
    tableSize = bsize;

    table = new int[bsize];     // memory allocation 

    for (unsigned int i = 0; i < bsize; i++)    // sets all indexes to -1 
    {
        table[i] = -1;
    }
}

//deconstrucotr 
HashTable::~HashTable()
{
    delete [] table; 
    table = NULL;
}

// hash function to map values to key
unsigned int HashTable::hashFunction(int key)
{
    return key % tableSize;
}
// double hashing function for collision resolution 
unsigned int HashTable::hashFunctionDH(int key)
{
    return (8363 - (key % 8363));
}

// inserting the key 
bool HashTable::insertItem(int key)
{
    int index = hashFunction(key);          // getting both indexes
    int index2 = hashFunctionDH(key);
    int di_index = index;
    if (table[index] == -1)             // index is free and no collision 
    {
        table[index] = key;
        return true;
    }
    else                // collision case 
    {

        int i=1;
        if(table[di_index] == -1)       //extra check to afraid to remove incase file falls apart
            table[di_index] = key;
        else
        {
            while (table[di_index] != -1)               // double hashing to next free index 
            {
                numOfcolision++;                            // counting number of coll 
                di_index= (index + i*index2)%tableSize;       // double hashing 
                i++;
                if(i==tableSize)
                {       
                    i = 0;                     // breaking if i gets too big 
                    break; 
                }
            }
            if (i != 0)
            {
                table[di_index] = key;
                return true; 
            }

        }
        return true; 
    }
}

//print the tbale 
void HashTable::printTable()
{
    cout << "Printing out double Hash table." << endl; 
   for (unsigned int i = 0; i < tableSize; i++)
   {
       cout << "Index: " << i << ". Key: " << table[i] << endl;    
   }
}

// reset num collisions 

void HashTable::resetCollisons()
{
    numOfcolision = 0; 
    return;
}

//returning the number of collisions
int HashTable::getNumOfCollision()
{
    return numOfcolision;
}

// searching for the key 
int HashTable::searchItem(int key)
{

    unsigned int index = hashFunction(key);             // getting both indexes 
    unsigned int index2 = hashFunctionDH(key);
    unsigned int newIndex = index;
    unsigned int i = 1;
    if (table[index] == key)                // no collisions case 
    {

        return table[index];
    }
    else 
    {
        while (table[newIndex] != key || table[newIndex] != -1)     // double hashing to the next indexes to find the next key 
        {
            numOfcolision++;
            newIndex = (index + i*index2)%tableSize;
            i++;
            if(i==tableSize)
            {
                i = 0;
                break;
            }
                
        }
        if (table[newIndex] == key)         // if key was found case 
        {
            return table[newIndex];
        }
        else                                 // if the key was not found 
        {
            return 0;
        }
    }

    return -1;
}