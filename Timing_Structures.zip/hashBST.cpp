#include "hashBST.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

//constructor
HashTable::HashTable(int bsize)
{
    tableSize = bsize;

    table = new BST[bsize];                     // creating table of input size 
    for (unsigned int i = 0; i < bsize; i++)
    {
        table[i] = BST();                           // seeting the indexes of the table to BSTs
    }
}

//deconstrucor 
HashTable::~HashTable()
{
    delete [] table;            // destorying the table 
    table = NULL; 
}

// hash function to map values to key
unsigned int HashTable::hashFunction(int key)
{
    return key % tableSize;
}

// inserting the item into the table 
bool HashTable::insertItem(int key)
{
    int index = hashFunction(key);          // getting the index for the key 
    bool found = table[index].isEmpty();    // checking to see if the index is empty 
    if (found)
    {
        table[index].addNode(key);          // adding to the table at the index
        //int num = getNumOfCollision();
        return true;
    }
    else                                // collision and adding to the bst at that index and counting up num collisions
    {
        table[index].addNode(key);      
        numOfcolision++;                // collision count 
        return true;    
    }
    return false;
}

//prints out the has table and its BSTs
void HashTable::printTable()
{
    cout << "Hash Table, printing each BST at each index." << endl;
    for (unsigned int i = 0; i < tableSize; i++)
    { 
        table[i].printTree();
    }
}

// returns the number of collisions
int HashTable::getNumOfCollision()
{
    //numOfcolision++;
    return numOfcolision;
}

//resets the number of collisions
void HashTable::resetCollisons()
{
    numOfcolision = 0; 
    return;
}

// searching the table for a key 
// assumes the key has been inserted into the tree already just not at the root 
bool HashTable::searchItem(int key)
{
    int index = hashFunction(key);          // gettting the index 
    if (table[index].getRoot() != key)      // getting the number of collisions
    {
        numOfcolision++;
    }
    if (table[index].searchKey(key))    // no collision 
        return true;
    
    return false;
}