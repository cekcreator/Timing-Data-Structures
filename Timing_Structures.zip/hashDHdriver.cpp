#include "hashDH.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <chrono>
#include <random>
#include <unistd.h>
#include <thread>
#include "time.h"

using namespace std;

int main()
{
    //  variables for use 
    int bsize = 10009;
    HashTable insert(bsize);
    ifstream read("dataSetA-updated.csv"); 
    ofstream write("insert_search_performance_hashDH.csv");
    string line;
    int avgInsert = 0;
    int avgSearch = 0;
    int totalArr[10000];
    float insertTime[50];
    float searchTime[50];
    srand(time(0));                 // seeding the time
    int randNum = -1;
    int arrNum = -1;
    int q = 0;
    bool found;
    double time = 0;
    int randArr[200];
    int insertcollArr[50];
    int searchcollArr[50];

    int n = 0;
    while (getline(read, line, ','))        // adding the data from the file to the array 
    {
        int num = stoi(line);
        totalArr[n] = num;
        n++;
    }

    for (unsigned int i = 0; i < 50; i++)       // loop for total interations 
    {
        // starting and doing the insertion of data into the open adressing hash table 
        auto start = chrono::steady_clock::now();
        for (unsigned int k = q; k < q + 200; k++)
        {
            insert.insertItem(totalArr[k]);
        }
        auto end = chrono::steady_clock::now();  // end time of the insertion 

        insertcollArr[i] = insert.getNumOfCollision();      // gettting the number of collisions for ever 50 operations 

        insertTime[i] = chrono::duration_cast<chrono::nanoseconds>(end - start).count();  // getting the time it took for insertion
        avgInsert += chrono::duration_cast<chrono::nanoseconds>(end - start).count();

        for (unsigned int d = 0; d < 200; d++)  // generates the random numbers and inserts them into an array for use
        {
            randArr[d] = rand() % (200 + q);
        }

        insert.resetCollisons();        // resetting the number of collisons for the insert count to count for the search 
        
        auto start2 = chrono::steady_clock::now();       // starting timer for searching
        for (unsigned int a = 0; a < 200; a++)
        {
            randNum = randArr[a]; 
            arrNum = totalArr[randNum];         // checks random index 
            insert.searchItem(arrNum);     //returns bool just incase need to confirm 
        }
        auto end2 = chrono::steady_clock::now();         // end time 


        searchTime[i] = chrono::duration_cast<chrono::nanoseconds>(end2 - start2).count(); // calculates time
        avgSearch += chrono::duration_cast<chrono::nanoseconds>(end2 - start2).count();
        q += 200;                                                                           // keeping track of index in the totalArr 
        searchcollArr[i] = insert.getNumOfCollision();      // getting collisions
    } 

    //writitht the insert times to the file 
    for (int b = 0; b < 50; b++)
    {
        write   << insertTime[b] / 200 << endl;
    }
    // writing the search times to the file 
    write << "Search time below, insert time above" << endl; 
    for (int g = 0; g < 50; g++)
    {
        write << searchTime[g] / 200 << endl;
    }

    // below is only for my refercne 
    write << "Average insert time: " << (avgInsert / 200) << " , Average search time: " << (avgSearch / 200) << endl; 
    int collison = insert.getNumOfCollision() * 2;

    // writing the collisions of search and inser to the file 
    write << "Number of collisions for insertion: " << endl;
    for (int a = 0; a < 50; a++)
    {
        write << insertcollArr[a] << endl;
    }
    write << "Number of collisions for searching: " << endl;
    for (int c = 0; c < 50; c++)
    {
        write << searchcollArr[c] << endl;
    }

    // closing the files and the destorying the table 
    write.close();

    insert.~HashTable();
    return 0;
}