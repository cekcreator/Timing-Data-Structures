#ifndef BST_HPP
#define BST_HPP
//#include "hashBST.hpp"

//using namespace std;


//node structure 
struct Node{
    int key;
    Node* left ;
    Node* right;
};

class BST{
    private:
        Node* root;                     // root node of BST 
        Node* createNode(int data);     // creating a node
        Node* searchKeyHelper(Node*, int);      // searching for a key 
        Node* addNodeHelper(Node*, int);        // addind the node the tree helper
        void printTreeHelper(Node*);            // priunt helper



    public:
        bool isEmpty();                    // checking to see if it is empty
        void addNode(int);              // function to insert a node in the tree.
        bool searchKey(int);            // function to search a data in the tree
        void printTree();               //function to print the tree
        BST();                          // construcotr 
        ~BST();                            // desctrucotr 
        int getRoot();                     // returningthe root

        //void print2DUtil(int);
    
};
#endif
